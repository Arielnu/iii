import flusher.init
import flusher.sync
