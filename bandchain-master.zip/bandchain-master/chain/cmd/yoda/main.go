package main

import (
	"github.com/bandprotocol/bandchain/chain/yoda"
)

func main() {
	yoda.Main()
}
