<div align="center">
  <h1>📫 BandChain - Decentralized Oracle Network</h1>
  <b>WORKING DRAFT</b>
</div>

[![](https://img.shields.io/badge/chat-on%20Telegram%20💬-blue.svg)](https://t.me/bandprotocol)
[![](https://img.shields.io/badge/chat-on%20Discord%20🤖-violet.svg)](https://discord.gg/es9CK4)

Moved to [BandChain Github Wiki](https://github.com/bandprotocol/bandchain/wiki).
